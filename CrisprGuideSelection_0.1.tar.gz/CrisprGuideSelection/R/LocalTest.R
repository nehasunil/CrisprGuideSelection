focusRegions=read.table("/Users/neha/Desktop/test_focus.txt")

fakeRegion=c("A","H","E","N")

module1=focusRegions[13:20,]
module1 <- data.frame(lapply(module1, as.character), stringsAsFactors=FALSE)
for(i in 1:20){module1=rbind(module1,fakeRegion)}

module2=focusRegions[21:44,]
module2 <- data.frame(lapply(module2, as.character), stringsAsFactors=FALSE)
for(i in 1:7){module2=rbind(module2,fakeRegion)}

module3=focusRegions[45,]
module3 <- data.frame(lapply(module3, as.character), stringsAsFactors=FALSE)
for(i in 1:20){module3=rbind(module3,fakeRegion)}

module4=focusRegions[46:69,]
module4 <- data.frame(lapply(module4, as.character), stringsAsFactors=FALSE)
for(i in 1:17){module4=rbind(module4,fakeRegion)}

module5=fakeRegion
module5 <- data.frame(lapply(module5, as.character), stringsAsFactors=FALSE)
for(i in 1:27){module5=rbind(module5,fakeRegion)}

module6=focusRegions[70:82,]
module6 <- data.frame(lapply(module6, as.character), stringsAsFactors=FALSE)
for(i in 1:7){module6=rbind(module6,fakeRegion)}

module7=focusRegions[83:100,]
module7 <- data.frame(lapply(module7, as.character), stringsAsFactors=FALSE)
for(i in 1:29){module7=rbind(module7,fakeRegion)}

write.table(module1,"/Users/neha/Desktop/moduleDirectory/cluster_1.bed.gz")
write.table(module2,"/Users/neha/Desktop/moduleDirectory/cluster_2.bed.gz")
write.table(module3,"/Users/neha/Desktop/moduleDirectory/cluster_3.bed.gz")
write.table(module4,"/Users/neha/Desktop/moduleDirectory/cluster_4.bed.gz")
write.table(module5,"/Users/neha/Desktop/moduleDirectory/cluster_5.bed.gz")
write.table(module6,"/Users/neha/Desktop/moduleDirectory/cluster_6.bed.gz")
write.table(module7,"/Users/neha/Desktop/moduleDirectory/cluster_7.bed.gz")

clust= c(1,1,1,2,2,3,3,3,3,4,4,5,5,6,7,7,7,8)
go=c("g1","g2","g3","g1","g4","g1","g2","g4","g5","g4","g5","g1","g2","g1","g2","g3","g4","g6")
go_table_test=cbind(clust,go)

GOOfInterest=c("g1","g2","g3")
weightsForGO=c(1,2,3)
GOInput=as.data.frame(cbind(as.character(GOOfInterest),as.numeric(weightsForGO)))

go_table=go_table_test
test_minFractionFocusInModule=0.9
max_FractionModuleSpecific=0.
numRegions=30
